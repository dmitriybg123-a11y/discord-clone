const $ = (id) => document.getElementById(id);
const modal = $("modalBackdrop");
let mode = "register";
let currentUser = null;

function openModal(nextMode) {
  mode = nextMode;
  $("formError").textContent = "";
  $("authForm").reset();
  const registering = mode === "register";
  $("modalTitle").textContent = registering ? "Создать аккаунт" : "С возвращением";
  $("modalSubtitle").textContent = registering ? "Заполни данные, чтобы начать." : "Войди в своё пространство Astralis.";
  $("usernameField").classList.toggle("hidden", !registering);
  $("identityLabel").textContent = registering ? "Электронная почта" : "Логин или электронная почта";
  $("identity").placeholder = registering ? "name@example.com" : "Твой логин или email";
  $("password").autocomplete = registering ? "new-password" : "current-password";
  $("password").placeholder = registering ? "Минимум 8 символов" : "Твой пароль";
  $("submitBtn").innerHTML = registering ? 'Создать аккаунт <span>↗</span>' : 'Войти в аккаунт <span>↗</span>';
  $("switchText").innerHTML = registering
    ? 'Уже есть аккаунт? <button type="button" data-switch="login">Войти</button>'
    : 'Впервые здесь? <button type="button" data-switch="register">Создать аккаунт</button>';
  modal.classList.remove("hidden");
  $("identity").focus();
}
function closeModal() { modal.classList.add("hidden"); }
function showDashboard(user) {
  currentUser = user;
  $("welcomeView").classList.add("hidden");
  $("dashboardView").classList.remove("hidden");
  $("topActions").classList.add("hidden");
  $("welcomeName").textContent = user.username;
  $("profileName").textContent = user.username;
  $("profileEmail").textContent = user.email;
  $("avatarLetter").textContent = user.username.slice(0, 1).toUpperCase();
  $("dashUsername").textContent = user.username;
  $("dashEmail").textContent = user.email;
  const date = new Date(user.createdAt.replace(" ", "T") + "Z");
  $("dashCreated").textContent = Number.isNaN(date.getTime()) ? user.createdAt : date.toLocaleDateString("ru-RU", { day: "numeric", month: "long", year: "numeric" });
}
function showWelcome() {
  currentUser = null;
  $("dashboardView").classList.add("hidden");
  $("welcomeView").classList.remove("hidden");
  $("topActions").classList.remove("hidden");
}
async function request(url, data) {
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "same-origin",
    body: JSON.stringify(data)
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.error || "Что-то пошло не так.");
  return result;
}

document.addEventListener("click", (event) => {
  const opener = event.target.closest("[data-open]");
  const switcher = event.target.closest("[data-switch]");
  if (opener) openModal(opener.dataset.open);
  if (switcher) openModal(switcher.dataset.switch);
});
$("closeModal").addEventListener("click", closeModal);
modal.addEventListener("click", (event) => { if (event.target === modal) closeModal(); });
document.addEventListener("keydown", (event) => { if (event.key === "Escape") closeModal(); });

$("authForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = $("submitBtn");
  const error = $("formError");
  error.textContent = "";
  button.disabled = true;
  button.textContent = "Подожди...";
  try {
    const identity = $("identity").value.trim();
    const password = $("password").value;
    let result;
    if (mode === "register") {
      result = await request("/api/register", {
        username: $("username").value.trim(),
        email: identity,
        password
      });
    } else {
      result = await request("/api/login", { identity, password });
    }
    closeModal();
    showDashboard(result.user);
  } catch (err) {
    error.textContent = err.message;
  } finally {
    button.disabled = false;
    button.innerHTML = mode === "register" ? 'Создать аккаунт <span>↗</span>' : 'Войти в аккаунт <span>↗</span>';
  }
});

$("logoutBtn").addEventListener("click", async () => {
  try {
    await request("/api/logout", {});
    showWelcome();
  } catch (err) {
    alert(err.message);
  }
});

(async function restoreSession() {
  try {
    const response = await fetch("/api/me", { credentials: "same-origin" });
    if (response.ok) {
      const result = await response.json();
      showDashboard(result.user);
    }
  } catch (error) {
    console.error("Не удалось восстановить сессию:", error);
  }
})();