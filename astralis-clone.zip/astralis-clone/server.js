require("dotenv").config();

const path = require("path");
const fs = require("fs");
const express = require("express");
const session = require("express-session");
const SQLiteStoreFactory = require("connect-sqlite3")(session);
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const helmet = require("helmet");
const { rateLimit } = require("express-rate-limit");

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const isProduction = process.env.NODE_ENV === "production";

if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  console.error("Set SESSION_SECRET in your .env file (at least 32 characters).");
  process.exit(1);
}

const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "astralis.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL COLLATE NOCASE UNIQUE,
    email TEXT NOT NULL COLLATE NOCASE UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);

app.disable("x-powered-by");
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:"]
    }
  }
}));
app.use(express.json({ limit: "10kb" }));
app.use(express.urlencoded({ extended: false, limit: "10kb" }));

app.use(session({
  store: new SQLiteStoreFactory({ db: "sessions.sqlite", dir: dataDir }),
  name: "astralis.sid",
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: isProduction,
    maxAge: 1000 * 60 * 60 * 24 * 7
  }
}));

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Слишком много попыток. Попробуйте через 15 минут." }
});

function publicUser(user) {
  return { id: user.id, username: user.username, email: user.email, createdAt: user.created_at };
}
function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Сначала войдите в аккаунт." });
  next();
}

app.post("/api/register", authLimiter, async (req, res) => {
  try {
    const username = String(req.body.username || "").trim();
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");

    if (!/^[\p{L}\p{N}_-]{3,20}$/u.test(username)) {
      return res.status(400).json({ error: "Логин: от 3 до 20 символов, только буквы, цифры, _ и -." });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
      return res.status(400).json({ error: "Введите корректный адрес электронной почты." });
    }
    if (password.length < 8 || password.length > 72) {
      return res.status(400).json({ error: "Пароль должен содержать от 8 до 72 символов." });
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const insert = db.prepare("INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)");
    let result;
    try {
      result = insert.run(username, email, passwordHash);
    } catch (error) {
      if (String(error.code).includes("CONSTRAINT")) {
        return res.status(409).json({ error: "Этот логин или email уже зарегистрирован." });
      }
      throw error;
    }

    req.session.regenerate((err) => {
      if (err) return res.status(500).json({ error: "Не удалось создать сессию." });
      req.session.userId = Number(result.lastInsertRowid);
      req.session.save((saveErr) => {
        if (saveErr) return res.status(500).json({ error: "Не удалось сохранить сессию." });
        const user = db.prepare("SELECT id, username, email, created_at FROM users WHERE id = ?").get(req.session.userId);
        res.status(201).json({ user: publicUser(user) });
      });
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Внутренняя ошибка сервера." });
  }
});

app.post("/api/login", authLimiter, async (req, res) => {
  try {
    const identity = String(req.body.identity || "").trim();
    const password = String(req.body.password || "");
    const user = db.prepare("SELECT * FROM users WHERE username = ? COLLATE NOCASE OR email = ? COLLATE NOCASE").get(identity, identity);

    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ error: "Неверный логин, email или пароль." });
    }

    req.session.regenerate((err) => {
      if (err) return res.status(500).json({ error: "Не удалось создать сессию." });
      req.session.userId = user.id;
      req.session.save((saveErr) => {
        if (saveErr) return res.status(500).json({ error: "Не удалось сохранить сессию." });
        res.json({ user: publicUser(user) });
      });
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Внутренняя ошибка сервера." });
  }
});

app.get("/api/me", requireAuth, (req, res) => {
  const user = db.prepare("SELECT id, username, email, created_at FROM users WHERE id = ?").get(req.session.userId);
  if (!user) {
    return req.session.destroy(() => res.status(401).json({ error: "Аккаунт не найден." }));
  }
  res.json({ user: publicUser(user) });
});

app.post("/api/logout", requireAuth, (req, res) => {
  req.session.destroy((err) => {
    if (err) return res.status(500).json({ error: "Не удалось выйти из аккаунта." });
    res.clearCookie("astralis.sid", { httpOnly: true, sameSite: "lax", secure: isProduction });
    res.json({ ok: true });
  });
});

app.use(express.static(path.join(__dirname, "public")));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`Astralis Clone запущен: http://localhost:${PORT}`));
